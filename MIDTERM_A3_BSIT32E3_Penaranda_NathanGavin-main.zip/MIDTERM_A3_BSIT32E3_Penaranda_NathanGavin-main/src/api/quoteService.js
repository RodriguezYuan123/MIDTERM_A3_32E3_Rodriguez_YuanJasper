const API_URL = import.meta.env.VITE_API_URL;

// Fetch all quotes
export const getAllQuotes = async () => {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (error) {
        console.error("Error fetching quotes:", error);
        throw error;
    }
};

// Fetch by category
export const getQuotesByCategory = async (category) => {
    try {
        // Supports json-server filtering via query param
        const url = category === 'all' ? API_URL : `${API_URL}?category=${category}`;
        const response = await fetch(url);
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (error) {
        console.error("Error fetching quotes by category:", error);
        throw error;
    }
};

// Add new quote
export const addQuote = async (quote) => {
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(quote),
        });
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (error) {
        console.error("Error adding quote:", error);
        throw error;
    }
};
