import React, { useState, useEffect } from 'react';
import { getAllQuotes, getQuotesByCategory } from '../api/quoteService';
import QuoteCard from '../components/QuoteCard';
import FilterBar from '../components/FilterBar';

const Home = () => {
    // State: Data and UI state
    const [quotes, setQuotes] = useState([]);
    const [randomQuote, setRandomQuote] = useState(null);
    const [category, setCategory] = useState('all');
    const [loading, setLoading] = useState(true);

    // Effect: Fetch data when 'category' changes
    useEffect(() => {
        const fetchQuotes = async () => {
            setLoading(true);
            try {
                const data = category === 'all'
                    ? await getAllQuotes()
                    : await getQuotesByCategory(category);
                setQuotes(data);
            } catch (error) {
                console.error("Failed to fetch quotes", error);
            } finally {
                setLoading(false);
            }
        };
        fetchQuotes();
    }, [category]);

    // Effect: Pick random quote when 'quotes' list updates
    useEffect(() => {
        if (quotes.length > 0) {
            pickRandomQuote();
        } else {
            setRandomQuote(null);
        }
    }, [quotes]);

    const pickRandomQuote = () => {
        if (quotes.length === 0) return;
        const randomIndex = Math.floor(Math.random() * quotes.length);
        setRandomQuote(quotes[randomIndex]);
    };

    return (
        <div className="home-page">
            <FilterBar currentCategory={category} onFilterChange={setCategory} />
            <div className="quote-display-container">
                {loading ? <p>Loading...</p> :
                    randomQuote ? (
                        <>
                            <QuoteCard quote={randomQuote} />
                            <button className="new-quote-btn" onClick={pickRandomQuote}>Get Another Quote</button>
                        </>
                    ) : <p className="no-quotes">No quotes found.</p>
                }
            </div>
        </div>
    );
};

export default Home;
